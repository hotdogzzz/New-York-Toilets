Dataset:Directory_Of_Toilets_In_Public_Parks

Author: City of New York

Created: November 10th 2020

Description: A directory of public toilets in parks available in New Yorks boroughs. In the dataset are six different coulumns, each named after their respective categories. 
The six columns are:
  
Name: The name of each location where a public toilet is located.
Location: The adress of each public toilet.
Open year-round: Stating either yes, no or N/A if the toilet is open year-round.
Handicap accessible: Stating yes or N/A if the toilet is handicap accessible.
Borough: Which borough/part of New York each public toilet is located.
Comments: Various comments on each public toilet.


URL: https://data.cityofnewyork.us/Recreation/Directory-Of-Toilets-In-Public-Parks/hjae-yuav/about_data